function bigBtn(x) {
    x.style.height = "85px";
    x.style.width = "200px";
}

function normalBtn(x) {
   x.style.height = "50px";
   x.style.width = "200px";
}

// Custom Cursor Movement
document.addEventListener('mousemove', function(e) {
    const cursor = document.querySelector('.custom-cursor');
    cursor.style.left = e.pageX + 'px';
    cursor.style.top = e.pageY + 'px';
});

window.addEventListener('load', function () {
        const preloader = document.getElementById('preloader');
        preloader.style.display = 'none';
    });